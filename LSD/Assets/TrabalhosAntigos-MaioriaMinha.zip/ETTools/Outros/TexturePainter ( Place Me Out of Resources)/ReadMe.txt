CodeArtist.mx 2015
Hello there! Thanks for downloading this project. 
I hope you find it useful.

You can replace any model with the whale mode, the only thing you need to keep in mind is that your model uses the canvas material the whale has.

If you find some use for this project I would love to know, also if you like i can reference it at my site.
Also since this is a free project please consider a donating.

For a detailed tutorial you can visit: http://codeartist.mx/tutorials/dynamic-texture-painting/

For any contact visit: http://codeartist.mx/

Credits:

Code: Rodrigo Fernandez Diaz
Whale model: https://www.assetstore.unity3d.com/en/#!/content/3547
Brush Vector Art: http://the-intelligentleman.deviantart.com/art/Vector-Brush-351376214
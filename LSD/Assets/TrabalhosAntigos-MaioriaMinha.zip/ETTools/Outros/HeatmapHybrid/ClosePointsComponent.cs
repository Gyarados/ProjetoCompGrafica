﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.Entities;

public struct ClosePointsComponent : IComponentData {

    public int closePoints;

}

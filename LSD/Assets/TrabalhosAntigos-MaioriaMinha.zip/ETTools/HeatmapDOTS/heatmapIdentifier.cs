using Unity.Entities;


namespace heatmapDOTS
{
    public class heatmapIdentifier : IComponentData {
    
        public int index;
        public int closeBy;
    }
}